# Learning Lms

## Introduction

> Learning LMS - HTML template. Best for e-Learning, online courses, training centers, Online academy, Online Institute, Online School, College, University, and Online Instructor Websites.Image and idea from internate.<br>

1.Courses information <br>
2.Program Setting<br>
3.Admission Info<br>
4.Events<br> 
5.People Review<br>
6.Searching<br>


#Pages

1.Home<br>
2.Program<br>
3.Admission<br>
4.Who we are<br>
5.Events<br>
6.Contact<br>
